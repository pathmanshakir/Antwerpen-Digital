import{Component} from '@angular/core';


@Component({
    
        selector:'app-home',
        templateUrl: './home.component.html',
        styleUrls: ['./home.component.scss']
      
    })
    export class homeComponent{
        netImage:any = "../assets/MJ.jpg";
        title = 'app';
       
         }
         
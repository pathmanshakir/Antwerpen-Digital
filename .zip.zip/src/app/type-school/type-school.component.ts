import{Component} from '@angular/core';
import {Service1} from '../Services/Service1.service';
import{RootObject} from '../Services/Service1.service';
import{OnInit} from '@angular/core';


@Component({
    
        selector:'app-type-school',
        templateUrl: './type-school.component.html',
        styleUrls: ['./type-school.component.scss']
      
    })
    export class typeComponent implements OnInit{
        TypeOfSchool: RootObject;
        lat: number = 51.194609528298;
        lng: number = 4.4266640370477;
      constructor(private Service :Service1){

      }
      ngOnInit() {
        this.Service.getType()
                .subscribe(result => this.TypeOfSchool = result);
      }
       
         }
         
    
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { NavBarComponent } from './nav-bar/nav-bar.component';
import { AppComponent } from './app.component';
import { MDBBootstrapModule } from 'angular-bootstrap-md';
import { RouterModule } from "@angular/router";
import { FormsModule } from '@angular/forms';
import { homeComponent } from './home/home.component';
import {Service1} from './Services/Service1.service'
import { HttpClientModule } from '@angular/common/http';
import {typeComponent} from './type-school/type-school.component'
import { AgmCoreModule } from '@agm/core';
//import { HttpClientModule } from '@angular/common/http';






@NgModule({
  declarations: [
    AppComponent,
    NavBarComponent,
    homeComponent,
    typeComponent,
  
    ],
  imports: [
    BrowserModule,
    AgmCoreModule.forRoot({
      apiKey: 'AIzaSyDgc1pYI5ifwPc9y4-LopQ20XM5BA7m-4Q'}),
    MDBBootstrapModule.forRoot(),
    RouterModule.forRoot([
  
      { path: 'home', component: homeComponent},
      {path : 'type-school', component: typeComponent}
 
    ], { useHash: true }),
    FormsModule,
    HttpClientModule
  ],

  providers: [
   Service1
  ],
  bootstrap: [AppComponent]
})

export class AppModule { }
